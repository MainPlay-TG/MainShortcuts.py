from setuptools import setup
setup(
  name="MainShortcuts",
  version="1.1",
  packages=["MainShortcuts"],
  author="MainPlay TG",
  description="Сокращение и упрощение встроенных операций",
  install_requires=[]
)
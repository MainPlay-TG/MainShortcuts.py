from .main import *
dir=mdir
file=mfile
json=mjson
os=mos
path=mpath
str=mstr
var=mvar
proc=mproc

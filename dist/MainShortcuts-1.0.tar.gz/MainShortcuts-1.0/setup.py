from setuptools import setup
setup(
  name="MainShortcuts",
  version="1.0",
  packages=["MainShortcuts"],
  author="MainPlay YT",
  description="Сокращение и упрощение встроенных операций",
  install_requires=[]
)
from .main import *
dir=mdir
file=mfile
json=mjson
os=mos
path=mpath
str=mstr
proc=mproc

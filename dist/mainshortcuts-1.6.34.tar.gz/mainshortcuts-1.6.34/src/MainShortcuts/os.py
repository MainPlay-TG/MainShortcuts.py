import platform as _platform
platform=_platform.system() # Тип ОС
type=platform